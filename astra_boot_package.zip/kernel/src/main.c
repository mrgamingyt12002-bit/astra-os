#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdnoreturn.h>
#include <limine.h>
#include "astra_logo.h"

__attribute__((used, section(".limine_requests")))
static volatile uint64_t limine_base_revision[] = LIMINE_BASE_REVISION(6);

__attribute__((used, section(".limine_requests")))
static volatile struct limine_framebuffer_request framebuffer_request = {
    .id = LIMINE_FRAMEBUFFER_REQUEST_ID,
    .revision = 0
};

__attribute__((used, section(".limine_requests_start")))
static volatile uint64_t limine_requests_start_marker[] = LIMINE_REQUESTS_START_MARKER;

__attribute__((used, section(".limine_requests_end")))
static volatile uint64_t limine_requests_end_marker[] = LIMINE_REQUESTS_END_MARKER;

static noreturn void hcf(void) {
    for (;;) {
        asm volatile ("hlt");
    }
}

static uint32_t channel(uint8_t value, uint8_t size, uint8_t shift) {
    uint64_t max = ((uint64_t)1 << size) - 1;
    return (uint32_t)((((uint64_t)value * max) / 255) << shift);
}

static uint32_t pixel(struct limine_framebuffer *fb,
                      uint8_t r, uint8_t g, uint8_t b) {
    return channel(r, fb->red_mask_size, fb->red_mask_shift)
         | channel(g, fb->green_mask_size, fb->green_mask_shift)
         | channel(b, fb->blue_mask_size, fb->blue_mask_shift);
}

static uint8_t dim(uint8_t value, unsigned level) {
    return (uint8_t)(((unsigned)value * level) / 255);
}

static void draw_frame(struct limine_framebuffer *fb,
                       unsigned scale_percent, unsigned brightness,
                       unsigned progress) {
    volatile uint32_t *dst = (volatile uint32_t *)fb->address;
    size_t width = fb->width;
    size_t height = fb->height;
    size_t pitch = fb->pitch / 4;

    /* Deep midnight background with a restrained blue-violet tint. */
    for (size_t y = 0; y < height; ++y) {
        for (size_t x = 0; x < width; ++x) {
            unsigned blue_glow = (unsigned)((x * 8 / (width ? width : 1)) +
                                            (y * 5 / (height ? height : 1)));
            dst[y * pitch + x] = pixel(fb, 5, 4, (uint8_t)(15 + blue_glow));
        }
    }

    /* Scale the supplied ASTRA logo and centre it on screen. */
    size_t draw_w = (ASTRA_LOGO_WIDTH * scale_percent) / 100;
    size_t draw_h = (ASTRA_LOGO_HEIGHT * scale_percent) / 100;
    if (draw_w == 0 || draw_h == 0 || draw_w > width || draw_h > height) return;

    size_t left = (width - draw_w) / 2;
    size_t top = (height - draw_h) / 2;

    for (size_t y = 0; y < draw_h; ++y) {
        size_t sy = y * ASTRA_LOGO_HEIGHT / draw_h;
        for (size_t x = 0; x < draw_w; ++x) {
            size_t sx = x * ASTRA_LOGO_WIDTH / draw_w;
            uint16_t c = astra_logo_pixels[sy * ASTRA_LOGO_WIDTH + sx];
            if (c == 0) continue; /* transparent black background */

            uint8_t r5 = (uint8_t)((c >> 11) & 0x1f);
            uint8_t g6 = (uint8_t)((c >> 5) & 0x3f);
            uint8_t b5 = (uint8_t)(c & 0x1f);
            uint8_t r = (uint8_t)((r5 * 255) / 31);
            uint8_t g = (uint8_t)((g6 * 255) / 63);
            uint8_t b = (uint8_t)((b5 * 255) / 31);

            r = dim(r, brightness);
            g = dim(g, brightness);
            b = dim(b, brightness);
            dst[(top + y) * pitch + left + x] = pixel(fb, r, g, b);
        }
    }

    /* Minimal progress indicator below the logo. */
    size_t bar_w = width / 4;
    if (bar_w > 360) bar_w = 360;
    if (bar_w < 80) bar_w = 80;
    size_t bar_h = 4;
    size_t bar_x = (width - bar_w) / 2;
    size_t bar_y = top + draw_h + 24;

    if (bar_y + bar_h < height) {
        for (size_t y = 0; y < bar_h; ++y) {
            for (size_t x = 0; x < bar_w; ++x) {
                uint32_t color = pixel(fb, 35, 30, 65);
                if (x < (bar_w * progress) / 100)
                    color = pixel(fb, 100, 65, 255);
                dst[(bar_y + y) * pitch + bar_x + x] = color;
            }
        }
    }
}

static void delay(void) {
    for (volatile uint32_t i = 0; i < 3500000; ++i)
        asm volatile ("pause");
}

void kmain(void) {
    if (!LIMINE_BASE_REVISION_SUPPORTED(limine_base_revision))
        hcf();

    if (framebuffer_request.response == NULL ||
        framebuffer_request.response->framebuffer_count < 1)
        hcf();

    struct limine_framebuffer *fb =
        framebuffer_request.response->framebuffers[0];

    if (fb == NULL || fb->address == NULL ||
        fb->memory_model != LIMINE_FRAMEBUFFER_RGB || fb->bpp != 32)
        hcf();

    /* Gentle scale-and-fade reveal, followed by a completed progress bar. */
    for (unsigned frame = 0; frame <= 12; ++frame) {
        unsigned scale = 88 + frame;
        unsigned brightness = (frame * 255) / 12;
        unsigned progress = (frame * 75) / 12;
        draw_frame(fb, scale, brightness, progress);
        delay();
    }

    draw_frame(fb, 100, 255, 100);

    /* Keep the boot splash visible until the next kernel subsystem exists. */
    hcf();
}
